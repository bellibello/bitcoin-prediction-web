# Bitcoin-prediction
bitcoin prediction for next few hours
Hello, Group number:- 2
Team member name:-
            1)Nishant Tomar 
            2)Aditya Bhardwaj
            3)Vaibhav Jha
            4)Parth Bansal
 
            
Cryptocurrencies are a digital way of money in which all transactions are held electronically. 
It is a virtual currency which doesn't exist in the form of hard notes physically. 
Here, we are emphasizing the difference of fiat currency which is decentralized that without any third-party intervention all virtual currency users can get the services. 
However, getting services of these cryptocurrencies impacts on international relations and trade, due to its high price volatility. 
There are several virtual currencies such as bitcoin, ripple, ethereum, ethereum classic, litecoin, etc.

In our study, we focused on a popular cryptocurrency, i.e.. bitcoin. 
From many types of virtual currencies, bitcoin has a great acceptance by different bodies such as investors, researchers, traders, and policy-makers.

To the best of our knowledge, our target is to implement the efficient deep learning-based prediction models, 
specifically long short-term memory (LSTM) to handle the price volatility of bitcoin and to obtain high accuracy.








# refrence:-
Data has been taken using API of https://twelvedata.com/

